var searchData=
[
  ['nopermissionexception_506',['NoPermissionException',['../classdiscpp_1_1NoPermissionException.html',1,'discpp']]],
  ['notguildownerexception_507',['NotGuildOwnerException',['../classdiscpp_1_1NotGuildOwnerException.html',1,'discpp']]]
];
