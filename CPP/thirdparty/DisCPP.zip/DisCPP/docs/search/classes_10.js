var searchData=
[
  ['typingstartevent_527',['TypingStartEvent',['../classdiscpp_1_1TypingStartEvent.html',1,'discpp']]]
];
