var searchData=
[
  ['reaction_732',['Reaction',['../classdiscpp_1_1Reaction.html#a8f150d81a089ad613d355d3278df5dd1',1,'discpp::Reaction']]],
  ['registerlistener_733',['RegisterListener',['../classdiscpp_1_1EventHandler.html#aa76ee54f5dac08cd7f74099c5c276ae5',1,'discpp::EventHandler']]],
  ['removebotreaction_734',['RemoveBotReaction',['../classdiscpp_1_1Message.html#a27a384b28afbbd4c36f800ba36efabfd',1,'discpp::Message']]],
  ['removefriend_735',['RemoveFriend',['../classdiscpp_1_1Client.html#adf53a707ec2dffec5d3f34483ff06dbb',1,'discpp::Client']]],
  ['removelistener_736',['RemoveListener',['../classdiscpp_1_1EventHandler.html#a0f0408019a68e16ca8bff01587673b21',1,'discpp::EventHandler']]],
  ['removemember_737',['RemoveMember',['../classdiscpp_1_1Guild.html#a487d1bd0408ca74f18b2b2e2e62fda95',1,'discpp::Guild']]],
  ['removereaction_738',['RemoveReaction',['../classdiscpp_1_1Message.html#a65b23fb32f17c531e22a9cd589d088ec',1,'discpp::Message']]],
  ['removerole_739',['RemoveRole',['../classdiscpp_1_1Member.html#a541f85dfd0134baf03420d2c3da82126',1,'discpp::Member']]],
  ['reqestuserifnotcached_740',['ReqestUserIfNotCached',['../classdiscpp_1_1Client.html#a35c3ada7dd80765541b05de44fa701c7',1,'discpp::Client']]],
  ['requestchannel_741',['RequestChannel',['../classdiscpp_1_1Channel.html#aadbe5617a07799afa37926e75663d029',1,'discpp::Channel']]],
  ['requestmessage_742',['RequestMessage',['../classdiscpp_1_1Channel.html#af3c4cfe274e5001489049e1d3a60fa4a',1,'discpp::Channel']]],
  ['requestmessages_743',['RequestMessages',['../classdiscpp_1_1Channel.html#a2c99abb36c7f4b32a1e2bba2609a6879',1,'discpp::Channel']]],
  ['role_744',['Role',['../classdiscpp_1_1Role.html#ad29698a59523e2a5b803ca0717fb75cc',1,'discpp::Role::Role(const Snowflake &amp;role_id, const discpp::Guild &amp;guild)'],['../classdiscpp_1_1Role.html#a9bb03f275b08fb43a6c28b7a97a267ab',1,'discpp::Role::Role(rapidjson::Document &amp;json)']]],
  ['run_745',['Run',['../classdiscpp_1_1Client.html#a3d487f007e402be57e0803d1a0455eb8',1,'discpp::Client']]]
];
