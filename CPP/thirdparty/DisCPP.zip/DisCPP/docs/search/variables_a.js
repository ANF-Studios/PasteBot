var searchData=
[
  ['last_5fmessage_5fid_813',['last_message_id',['../classdiscpp_1_1Channel.html#a81c10e5413a26c77326fec3bba2c0394',1,'discpp::Channel']]],
  ['last_5fpin_5ftimestamp_814',['last_pin_timestamp',['../classdiscpp_1_1Channel.html#a027fdd61d98a12d527eaced36428de16',1,'discpp::Channel']]],
  ['logger_815',['logger',['../classdiscpp_1_1Client.html#a1f3a21dae7be1fcfd52b82fdcac9e4c5',1,'discpp::Client']]]
];
