var searchData=
[
  ['leaveguild_694',['LeaveGuild',['../classdiscpp_1_1Client.html#a04658448897e6a07c86c18f551672ab0',1,'discpp::Client']]],
  ['logger_695',['Logger',['../classdiscpp_1_1Logger.html#a12212470a7bff5ec21966cdd5eea8226',1,'discpp::Logger::Logger(const std::string &amp;file_path, const int &amp;logger_flags=logger_flags::ALL_SEVERITY)'],['../classdiscpp_1_1Logger.html#a0c2b25c4bd13fa3dc3ba749f8718253d',1,'discpp::Logger::Logger(const int &amp;logger_flags=logger_flags::ALL_SEVERITY)']]]
];
