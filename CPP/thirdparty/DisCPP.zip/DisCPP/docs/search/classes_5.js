var searchData=
[
  ['featuredisabledexception_456',['FeatureDisabledException',['../classdiscpp_1_1exceptions_1_1FeatureDisabledException.html',1,'discpp::exceptions']]],
  ['file_457',['File',['../structdiscpp_1_1File.html',1,'discpp']]],
  ['friendsource_458',['FriendSource',['../classdiscpp_1_1FriendSource.html',1,'discpp']]]
];
