var searchData=
[
  ['unbanmember_394',['UnbanMember',['../classdiscpp_1_1Guild.html#a78b13e6adccb2d8a5052d7198d1a61fe',1,'discpp::Guild']]],
  ['unbanmemberbyid_395',['UnbanMemberById',['../classdiscpp_1_1Guild.html#a4d70824b1226df3012d2f56d6fa92ae9',1,'discpp::Guild']]],
  ['unicode_396',['unicode',['../classdiscpp_1_1Emoji.html#a6f560caa00b2a0e83e76f67d78cfe620',1,'discpp::Emoji']]],
  ['unpinmessage_397',['UnpinMessage',['../classdiscpp_1_1Message.html#af98588e810a17c743156c53043ab6f84',1,'discpp::Message']]],
  ['updatepresence_398',['UpdatePresence',['../classdiscpp_1_1Client.html#aaf9e050d856cb326addb8ec82a9b6149',1,'discpp::Client']]],
  ['url_399',['url',['../classdiscpp_1_1Attachment.html#af48247d5504c094b45611b70586b1a56',1,'discpp::Attachment']]],
  ['user_400',['User',['../classdiscpp_1_1User.html',1,'discpp::User'],['../structdiscpp_1_1GuildBan.html#a5b345284ef59f3cd232738f3995640d7',1,'discpp::GuildBan::user()'],['../classdiscpp_1_1Integration.html#a8fd0d8875112fe0b5c3cf690c26efc96',1,'discpp::Integration::user()'],['../classdiscpp_1_1Member.html#a5ac3acf0ce5b039abce6481e2f05d224',1,'discpp::Member::user()'],['../classdiscpp_1_1User.html#a5586267401bea6cc67e7e00a86df8383',1,'discpp::User::User(const Snowflake &amp;id)'],['../classdiscpp_1_1User.html#a9bf6608bbe9c4e105b4d296cedbdd6a0',1,'discpp::User::User(rapidjson::Document &amp;json)']]],
  ['user_5fid_401',['user_id',['../classdiscpp_1_1VoiceState.html#a7ebeeefa814a1197f9d1d1bd9f749dc2',1,'discpp::VoiceState']]],
  ['user_5flimit_402',['user_limit',['../classdiscpp_1_1Channel.html#ad09d4306599bc7d79ba031cac000eb4b',1,'discpp::Channel']]],
  ['username_403',['username',['../classdiscpp_1_1User.html#af9f2411fd205e655136b23a70e918278',1,'discpp::User']]],
  ['userrelationship_404',['UserRelationship',['../classdiscpp_1_1UserRelationship.html',1,'discpp']]],
  ['userupdateevent_405',['UserUpdateEvent',['../classdiscpp_1_1UserUpdateEvent.html',1,'discpp']]]
];
