var searchData=
[
  ['voicestate_773',['VoiceState',['../classdiscpp_1_1VoiceState.html#a9046facbcac52a15e2ca2e9e23f0398a',1,'discpp::VoiceState']]]
];
