var searchData=
[
  ['vanity_5furl_5fcode_867',['vanity_url_code',['../classdiscpp_1_1Guild.html#ab7f651136efc79e90150f6433e92e59f',1,'discpp::Guild']]],
  ['verification_5flevel_868',['verification_level',['../classdiscpp_1_1Guild.html#a563a68df1e8345c44a7712d116d80930',1,'discpp::Guild']]],
  ['voice_5fstates_869',['voice_states',['../classdiscpp_1_1Guild.html#a3c162a2ebedfaaf1011192a40b315953',1,'discpp::Guild']]]
];
