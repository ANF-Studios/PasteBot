var searchData=
[
  ['bit_5fflags_782',['bit_flags',['../classdiscpp_1_1Message.html#a1287e616421d5feb34cfe89adb38771f',1,'discpp::Message']]],
  ['bitrate_783',['bitrate',['../classdiscpp_1_1Channel.html#ae36d008a7e59c954c41a74918940b449',1,'discpp::Channel']]]
];
