var searchData=
[
  ['unbanmember_768',['UnbanMember',['../classdiscpp_1_1Guild.html#a78b13e6adccb2d8a5052d7198d1a61fe',1,'discpp::Guild']]],
  ['unbanmemberbyid_769',['UnbanMemberById',['../classdiscpp_1_1Guild.html#a4d70824b1226df3012d2f56d6fa92ae9',1,'discpp::Guild']]],
  ['unpinmessage_770',['UnpinMessage',['../classdiscpp_1_1Message.html#af98588e810a17c743156c53043ab6f84',1,'discpp::Message']]],
  ['updatepresence_771',['UpdatePresence',['../classdiscpp_1_1Client.html#aaf9e050d856cb326addb8ec82a9b6149',1,'discpp::Client']]],
  ['user_772',['User',['../classdiscpp_1_1User.html#a5586267401bea6cc67e7e00a86df8383',1,'discpp::User::User(const Snowflake &amp;id)'],['../classdiscpp_1_1User.html#a9bf6608bbe9c4e105b4d296cedbdd6a0',1,'discpp::User::User(rapidjson::Document &amp;json)']]]
];
