var searchData=
[
  ['kickmember_692',['KickMember',['../classdiscpp_1_1Guild.html#a4138d0550681fbef35a4e51e45eba248',1,'discpp::Guild']]],
  ['kickmemberbyid_693',['KickMemberById',['../classdiscpp_1_1Guild.html#ab440725b39ddfc6af5ea776cf4c695ba',1,'discpp::Guild']]]
];
