var searchData=
[
  ['banmember_23',['BanMember',['../classdiscpp_1_1Guild.html#a227ab31b2eb84b352cdb549616a646a0',1,'discpp::Guild']]],
  ['banmemberbyid_24',['BanMemberById',['../classdiscpp_1_1Guild.html#a628ad991481c94bd8a6243c9952333ae',1,'discpp::Guild']]],
  ['bannedexception_25',['BannedException',['../classdiscpp_1_1exceptions_1_1BannedException.html',1,'discpp::exceptions']]],
  ['beginprune_26',['BeginPrune',['../classdiscpp_1_1Guild.html#a3e8f875725d905a8e03e4ccdf85605ed',1,'discpp::Guild']]],
  ['bit_5fflags_27',['bit_flags',['../classdiscpp_1_1Message.html#a1287e616421d5feb34cfe89adb38771f',1,'discpp::Message']]],
  ['bitrate_28',['bitrate',['../classdiscpp_1_1Channel.html#ae36d008a7e59c954c41a74918940b449',1,'discpp::Channel']]],
  ['bulkdeletemessage_29',['BulkDeleteMessage',['../classdiscpp_1_1Channel.html#a472d2e7e3df8714f1d2a93c8e49929a0',1,'discpp::Channel']]]
];
