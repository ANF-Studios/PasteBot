var searchData=
[
  ['vanity_5furl_5fcode_406',['vanity_url_code',['../classdiscpp_1_1Guild.html#ab7f651136efc79e90150f6433e92e59f',1,'discpp::Guild']]],
  ['verification_5flevel_407',['verification_level',['../classdiscpp_1_1Guild.html#a563a68df1e8345c44a7712d116d80930',1,'discpp::Guild']]],
  ['voice_5fstates_408',['voice_states',['../classdiscpp_1_1Guild.html#a3c162a2ebedfaaf1011192a40b315953',1,'discpp::Guild']]],
  ['voiceserverupdateevent_409',['VoiceServerUpdateEvent',['../classdiscpp_1_1VoiceServerUpdateEvent.html',1,'discpp']]],
  ['voicestate_410',['VoiceState',['../classdiscpp_1_1VoiceState.html',1,'discpp::VoiceState'],['../classdiscpp_1_1VoiceState.html#a9046facbcac52a15e2ca2e9e23f0398a',1,'discpp::VoiceState::VoiceState()']]],
  ['voicestateupdateevent_411',['VoiceStateUpdateEvent',['../classdiscpp_1_1VoiceStateUpdateEvent.html',1,'discpp']]]
];
