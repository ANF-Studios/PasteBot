var searchData=
[
  ['banmember_543',['BanMember',['../classdiscpp_1_1Guild.html#a227ab31b2eb84b352cdb549616a646a0',1,'discpp::Guild']]],
  ['banmemberbyid_544',['BanMemberById',['../classdiscpp_1_1Guild.html#a628ad991481c94bd8a6243c9952333ae',1,'discpp::Guild']]],
  ['beginprune_545',['BeginPrune',['../classdiscpp_1_1Guild.html#a3e8f875725d905a8e03e4ccdf85605ed',1,'discpp::Guild']]],
  ['bulkdeletemessage_546',['BulkDeleteMessage',['../classdiscpp_1_1Channel.html#a472d2e7e3df8714f1d2a93c8e49929a0',1,'discpp::Channel']]]
];
