var searchData=
[
  ['deaf_793',['deaf',['../classdiscpp_1_1VoiceState.html#a6588bc10348174b464ce6fa43895f11c',1,'discpp::VoiceState']]],
  ['default_5fmessage_5fnotifications_794',['default_message_notifications',['../classdiscpp_1_1Guild.html#a0626e89e9ecd5068a21e22e77f327948',1,'discpp::Guild']]],
  ['description_795',['description',['../classdiscpp_1_1Command.html#a25280c44843b4a03b90525d67c4ebd6e',1,'discpp::Command::description()'],['../classdiscpp_1_1Guild.html#a19380661119a4134e7a28e11ac83f4ee',1,'discpp::Guild::description()']]]
];
