var searchData=
[
  ['ratelimit_516',['Ratelimit',['../classdiscpp_1_1Ratelimit.html',1,'discpp::Ratelimit'],['../structdiscpp_1_1RateLimit.html',1,'discpp::RateLimit']]],
  ['reaction_517',['Reaction',['../classdiscpp_1_1Reaction.html',1,'discpp']]],
  ['readyevent_518',['ReadyEvent',['../classdiscpp_1_1ReadyEvent.html',1,'discpp']]],
  ['reconnectevent_519',['ReconnectEvent',['../classdiscpp_1_1ReconnectEvent.html',1,'discpp']]],
  ['requestchannelsmessagemethod_520',['RequestChannelsMessageMethod',['../structdiscpp_1_1RequestChannelsMessageMethod.html',1,'discpp']]],
  ['requesttoolargeexception_521',['RequestTooLargeException',['../classdiscpp_1_1exceptions_1_1RequestTooLargeException.html',1,'discpp::exceptions']]],
  ['resumedevent_522',['ResumedEvent',['../classdiscpp_1_1ResumedEvent.html',1,'discpp']]],
  ['role_523',['Role',['../classdiscpp_1_1Role.html',1,'discpp']]]
];
