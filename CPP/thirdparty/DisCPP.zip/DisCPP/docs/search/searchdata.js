var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvw",
  1: "abcdefghilmnoprstuvw",
  2: "abcdefghiklmprstuvw",
  3: "abcdefghijlmnoprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

