var searchData=
[
  ['unicode_861',['unicode',['../classdiscpp_1_1Emoji.html#a6f560caa00b2a0e83e76f67d78cfe620',1,'discpp::Emoji']]],
  ['url_862',['url',['../classdiscpp_1_1Attachment.html#af48247d5504c094b45611b70586b1a56',1,'discpp::Attachment']]],
  ['user_863',['user',['../structdiscpp_1_1GuildBan.html#a5b345284ef59f3cd232738f3995640d7',1,'discpp::GuildBan::user()'],['../classdiscpp_1_1Integration.html#a8fd0d8875112fe0b5c3cf690c26efc96',1,'discpp::Integration::user()'],['../classdiscpp_1_1Member.html#a5ac3acf0ce5b039abce6481e2f05d224',1,'discpp::Member::user()']]],
  ['user_5fid_864',['user_id',['../classdiscpp_1_1VoiceState.html#a7ebeeefa814a1197f9d1d1bd9f749dc2',1,'discpp::VoiceState']]],
  ['user_5flimit_865',['user_limit',['../classdiscpp_1_1Channel.html#ad09d4306599bc7d79ba031cac000eb4b',1,'discpp::Channel']]],
  ['username_866',['username',['../classdiscpp_1_1User.html#af9f2411fd205e655136b23a70e918278',1,'discpp::User']]]
];
