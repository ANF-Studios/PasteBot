var searchData=
[
  ['name_824',['name',['../structdiscpp_1_1AuditLogChangeKey.html#a0bb315f62ee358f525c9e1e0485382c3',1,'discpp::AuditLogChangeKey::name()'],['../classdiscpp_1_1Channel.html#a1faf5de9b78ea37e3de586783855e002',1,'discpp::Channel::name()'],['../classdiscpp_1_1Command.html#ae9eedd2e6de5081d97fb7d01fc90c1c7',1,'discpp::Command::name()'],['../classdiscpp_1_1Emoji.html#a3f2630adb3a75aeb512ccd81cb8cba2c',1,'discpp::Emoji::name()'],['../classdiscpp_1_1IntegrationAccount.html#aa263e968697701b2221c8540228576cc',1,'discpp::IntegrationAccount::name()'],['../classdiscpp_1_1Integration.html#adeb8a1800876f35e2f147cbf3e39dd72',1,'discpp::Integration::name()'],['../classdiscpp_1_1Guild.html#ad0ee69fc36f1c92e0255c80f44c0f734',1,'discpp::Guild::name()'],['../classdiscpp_1_1Role.html#a39f67c0e0a45b5845f22b7f2884e85f7',1,'discpp::Role::name()']]],
  ['nick_825',['nick',['../classdiscpp_1_1Member.html#a9465bbcdd1128f062cc939bf6fcfe1c0',1,'discpp::Member']]],
  ['nsfw_826',['nsfw',['../classdiscpp_1_1Channel.html#a6c2d38e9e48fadf13633d257d04b502e',1,'discpp::Channel']]]
];
