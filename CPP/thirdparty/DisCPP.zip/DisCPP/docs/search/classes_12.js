var searchData=
[
  ['voiceserverupdateevent_531',['VoiceServerUpdateEvent',['../classdiscpp_1_1VoiceServerUpdateEvent.html',1,'discpp']]],
  ['voicestate_532',['VoiceState',['../classdiscpp_1_1VoiceState.html',1,'discpp']]],
  ['voicestateupdateevent_533',['VoiceStateUpdateEvent',['../classdiscpp_1_1VoiceStateUpdateEvent.html',1,'discpp']]]
];
