var searchData=
[
  ['rate_5flimit_5fper_5fuser_838',['rate_limit_per_user',['../classdiscpp_1_1Channel.html#a301fd4ee82ffc19b732a3b97a31fd54f',1,'discpp::Channel']]],
  ['reason_839',['reason',['../structdiscpp_1_1GuildBan.html#ae00456cf08d665888df284409d4530e3',1,'discpp::GuildBan']]],
  ['recipients_840',['recipients',['../classdiscpp_1_1Channel.html#aa140c329de05e257ec57ae63dbafe227',1,'discpp::Channel']]],
  ['region_841',['region',['../structdiscpp_1_1AuditLogChangeKey.html#a779fa19e685c525ebaed8775559b89f8',1,'discpp::AuditLogChangeKey::region()'],['../classdiscpp_1_1Guild.html#ad94b0e4620f33743f095311a7522d597',1,'discpp::Guild::region()']]],
  ['role_5fid_842',['role_id',['../classdiscpp_1_1Integration.html#a93b2cade0cf558a1ca274112b2404d83',1,'discpp::Integration']]],
  ['roles_843',['roles',['../classdiscpp_1_1Emoji.html#a7ff4cbfa7d5c1828c9ac3c9ad8bfad31',1,'discpp::Emoji::roles()'],['../classdiscpp_1_1Guild.html#a02a51e3b40ceb19bfa54a41737bd7523',1,'discpp::Guild::roles()']]],
  ['rules_5fchannel_5fid_844',['rules_channel_id',['../classdiscpp_1_1Guild.html#a377f43044e0f9019d90fad5830499f03',1,'discpp::Guild']]]
];
