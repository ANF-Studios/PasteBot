var searchData=
[
  ['discordobject_444',['DiscordObject',['../classdiscpp_1_1DiscordObject.html',1,'discpp']]],
  ['discordobjectnotfound_445',['DiscordObjectNotFound',['../classdiscpp_1_1exceptions_1_1DiscordObjectNotFound.html',1,'discpp::exceptions']]]
];
